# Blender Extension Test

A set of [Blender](https://blender.org) [extensions](https://extensions.blender.org)
put together for testing how to develop and how to deploy them.

## ⚡ Getting Started

TBD, but the idea is to use this repo's GitHub Pages site as static extension registry for Blender.

## 🔧 Building and Running

TBD, but basically install the **Blender Development** VSCode extension by Jacques Lucke,
then call `Blender: Start` and `Blender: Reload Extensions`.

### 🔨 Build the Project

Install the `fake-bpy-module` package to allow local code compilation and code completion.

```shell
pip install fake-bpy-module
```

### ▶ Running and Settings

TBD

## 🤝 Collaborate with My Project

Please refer to [COLLABORATION.md](./COLLABORATION.md)
